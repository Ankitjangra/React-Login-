import './App.css';
import Login from './components/Login';
import UserData from './components/UserData';

import { useState } from 'react';

import {BrowserRouter as Router,Route,Routes} from 'react-router-dom';

function App() {
  const [isLoggedIn,setIsLoggedIn] = useState(false);

  const handleLogin = () => {
    setIsLoggedIn(true);
  }
 
  return (
    <Router>
     {/* <Switch> */}
     <Routes>
      
       <Route path='/login' Component={Login}></Route>
       <Route path='/userData' Component={UserData}></Route>
     {/* </Switch> */}
     </Routes>
    </Router>
  );
}

export default App;
