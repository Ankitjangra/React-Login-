import React ,{useState} from 'react';
import { useNavigate } from 'react-router-dom';
import UserData from './UserData';

const Login = ()=>{
    const [userName,setUserName] = useState('');
    const [password,setPassword] = useState('');
    const [authToken,setAuthToken] = useState('');
    const navigate = useNavigate();

    const handleLogin = async() => {
        try{
            const response = await fetch('https://f88cebef-2139-459c-8447-11f5ccebfcb4.mock.pstmn.io/login',{
                method: 'POST',
                headers:{
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({userName,password})
            });
            console.log("response from login api",response);
            if(response.ok){
                const data = await response.json();
                console.log("data:::",data);
                setAuthToken(data.response);
                navigate('/userData');
            }else{
                console.error('login failed');
            }
        }catch(err){
            console.error("error",err);
        }
    };
    return(
        <div>
            <label>Name:
            <input type='text' value={userName} onChange={(e)=> setUserName(e.target.value)}/>
            </label>
            <label>password:
            <input type='password' value={password} onChange={(e)=> setPassword(e.target.value)}/>
            </label>
            <button onClick={handleLogin}>Login</button>

            {/* {authToken && <UserData authToken={authToken}/>} */}
        </div>
    ); 
};

export default Login;

