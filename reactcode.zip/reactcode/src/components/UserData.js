import React ,{useState,useEffect} from 'react';

const UserData = ({authToken}) => {
    const [apiData,setApiData]= useState(null);


    const fetchData = async ()=>{
        try{
            const response =await fetch("https://f88cebef-2139-459c-8447-11f5ccebfcb4.mock.pstmn.io/getdata",{
                headers :{
                    Authorization: `Bearer ${authToken}`,
                },
            })
            console.log(response);
            if(response.ok){
                const data = await response.json();
                console.log("Data:::::",data);
                setApiData(data.response);
            }else{
                console.error("err");
            }
        }catch(err){
            console.error("catch err",err);
        }
    }

    useEffect(()=>{
        fetchData();
        const intervalId = setInterval(()=>{
            fetchData();
        },10000);

        return ()=> clearInterval(intervalId);
    },[authToken]);

    return(
        <div>
            <h2>User Data</h2>
            {apiData ? (apiData.map((d)=> (
                <div key={d}>
                    <p>Name: {d}</p>  
                </div>
            ))) : ''}
        </div>
    );
}

export default UserData;
